#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 100000000
typedef struct{
    long int* lista;
    long int length;
} Lista;

Lista pierwsze(long int k){
    Lista var;
    if(k<2){
      	var.length=0;
    	return var;
    }
    int* l = malloc(k*sizeof(int));

    for(long int i=2;i<k;i++){
        l[i]=1;
    }
    long int sqrt = (long int) round(sqrtl(k));
    for(long int i=2;i<sqrt;i++){
    	if(l[i]==1){
    	    for(long int j=i*i;j<k;j=j+i){
    	    	l[j]=0;
    	    }
    	}
    }
    long int ld=0;
    for(long int i=2;i<k;i++){
    	ld+=l[i];
    }
    var.length=ld;
    var.lista = malloc(ld*sizeof(long int));
    long int h=0;
    for(long int i=0;i<k;i++){
    	if(l[i]==1){
    	    var.lista[h]=i;
    	    h++;
    	}
    }
    return var;
    
}

int main(int argc, char **argv){
    Lista l = pierwsze(N);
    printf("\n%ld\n",l.length);
    return 1;
}
