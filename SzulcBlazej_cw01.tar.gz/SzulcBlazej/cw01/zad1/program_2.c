#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 10000000
#define K 1111
void scal(long int* lista,long int p,long int q, long int r){
    long int t = r-p;
    long int* tab = malloc(t*sizeof(long int));
    long int a=p;
    long int b=q;
    for(long int i=0;i<t;i++){
        if(a>=q){
            tab[i]=lista[b];
	    b++;
            continue;
        }
        if(b>=r){
            tab[i]=lista[a];
	    a++;
            continue;
        }
        if(lista[a]<lista[b]){
	    tab[i]=lista[a];
	    a++;
	    continue;
	}
        if(lista[b]<lista[a]){
            tab[i]=lista[b];
	    b++;
            continue;
        }
	if(lista[a]==lista[b]){
	    tab[i]=lista[a];
	    a++;
	    i++;
	    tab[i]=lista[b];
	    b++;
	    continue;
	}
    }
    for(long int i=0;i<t;i++){
        lista[p+i]=tab[i];
    }
}
void sort_scal(long* lista,long int p, long int r){
    long int q=(p+r)/2;
    if(p<r-1){
	sort_scal(lista,0,q);
        sort_scal(lista+q,0,r-q);
	scal(lista,p,q,r);
    }
}
int main(int argc, char **argv){
    srand(K);
    long int* tab = malloc(N*sizeof(long int));
    for(long int i=0;i<N;i++){
        tab[i]=rand();
    }
       sort_scal(tab,0,N);
    for(long int i=1;i<N;++i){
        if(tab[i-1]>tab[i]){
	    return 0;
	}
    }
    return 1;
}
