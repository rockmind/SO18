#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 100000000
#define K 1111
long double uelek(long double a, long double b,long unsigned int p){
    long double k=0;
    for(long unsigned int i=0;i<p;i++){
        if(fabs(b)<1.){
	    k+=powl(a,b);
	}
	else{
	    k=k*0.1;
	    b=b*0.1;
	    a=a*10;
	}
    }
    return k;
}
int main(int argc, char **argv){
    
    printf("Wynik=%Lf\n",uelek(10.,2.4,10000000));
    return 1;
}
