#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define N 10000
#define K 222
int main(int argc, char **argv){
    srand(K);
    FILE *fp;
    if((fp=fopen("wynik_program_3.txt","w"))==NULL){
        exit(1);
    }
    fprintf(fp,"%d\t",0);
    for(long int j=1;j<1+N/4;j++){
        fprintf(fp,"%ld\t",j);
    }
    fprintf(fp,"\n");
    for(long int i=1;i<N;i++){
        fprintf(fp,"%ld",i);
        for(long int j=0;j<N/4;j++){
            fprintf(fp,"\t%ld",(long int) rand());
	}
        fprintf(fp,"\n");
	if(i%4==1 || i%4==0){
            fprintf(fp,"\r\b\r");
	}
    }
    fprintf(fp,"\n");
    fclose(fp);
    return 1;
}
