long double uelek(long double a, long double b,long unsigned int p);
