#include <stdio.h>
#include <stdlib.h>
#include <math.h>

long double uelek(long double a, long double b,long unsigned int p){
    long double k=0;
    for(long unsigned int i=0;i<p;i++){
        if(fabs(b)<1.){
	    k+=a*b;
	}
	else{
	    k=k*0.1;
	    b=b*0.1;
	    a=a*10;
	}
    }
    return k;
}
