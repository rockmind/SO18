#include "lib_mylib.h"
#define N 100000000
#define K 1111
int main(int argc, char **argv){
    
    printf("Wynik=%Lf\n",uelek(10.,2.4,10000000));
    return 1;
}
