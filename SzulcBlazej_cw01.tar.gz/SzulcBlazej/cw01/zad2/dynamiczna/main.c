#include<dlfcn.h>
#define N 100000000
#define K 1111
int main(int argc, char **argv){
    void *handle = dlopen("libmylib.so",RTLD_LAZY);  
    long double (*lib_uelek)(long double,long double,long int);
    *(void **) (&lib_uelek) = dlsym(handle,"uelek");
    printf("Wynik=%Lf\n",(*lib_uelek)(10.,2.4,10000000));
    dlclose(handle);
    return 1;
}
