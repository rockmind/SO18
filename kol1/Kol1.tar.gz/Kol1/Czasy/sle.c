#include <unistd.h>

int main(){
  for(int i=1;i<10000000;i++){
    if(i%10 == 0){
  //    sleep(1);
    }
  }
  return 1;
}
